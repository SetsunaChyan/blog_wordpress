﻿Sakura🌸: A Wonderful WordPress Theme
===

![Sakura](https://view.moezx.cc/images/2018/05/26/sakura.png)

![PHP version from PHP-Eye](https://img.shields.io/php-eye/symfony/symfony.svg?style=flat-square)
[![GitHub release](https://img.shields.io/github/release/mashirozx/Sakura.svg?style=flat-square)](https://github.com/mashirozx/Sakura/releases/latest)
[![Github commits (since latest release)](https://img.shields.io/github/commits-since/mashirozx/Sakura/latest.svg?style=flat-square)](https://github.com/mashirozx/Sakura/commits/)
[![](https://data.jsdelivr.com/v1/package/gh/moezx/cdn/badge)](https://www.jsdelivr.com/package/gh/moezx/cdn)

在 Louie 基于 Fuzzz 的 [Akina](http://www.akina.pw/themeakina) 主题修改的主题 [Siren](https://github.com/louie-senpai/Siren) 基础上三次修改 =.=

两位前辈做得已经很棒了，或许我所做的只是把他们的代码弄得凌乱不堪吧 :)

注意：建议 `git clone` 下载；如果选择下载压缩包，解压后记得把文件夹名改回 `Sakura`，也即保证主题路径为 `/wp-content/themes/Sakura/`；请留意主题说明里的其他注意事项。

主题使用说明见：<https://2heng.xin/theme-sakura/>

希望你喜欢！

### 要饭

微信支付：  
<img src="https://view.moezx.cc/images/2018/05/28/WeChanQR.png" width="200"/>

支付宝：  
<img src="https://view.moezx.cc/images/2018/05/28/AliPayQR.jpg" width="200"/>

PayPal：
https://paypal.me/mashirozx
